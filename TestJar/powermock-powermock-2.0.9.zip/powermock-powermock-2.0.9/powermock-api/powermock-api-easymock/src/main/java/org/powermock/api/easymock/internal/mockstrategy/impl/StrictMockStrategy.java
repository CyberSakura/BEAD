package org.powermock.api.easymock.internal.mockstrategy.impl;

import org.easymock.MockType;

public class StrictMockStrategy extends AbstractMockStrategyBase {

	public StrictMockStrategy() {
		super(MockType.STRICT);
	}
}
