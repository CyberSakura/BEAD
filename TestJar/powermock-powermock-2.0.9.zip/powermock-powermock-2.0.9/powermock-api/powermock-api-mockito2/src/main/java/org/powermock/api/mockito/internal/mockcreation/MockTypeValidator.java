package org.powermock.api.mockito.internal.mockcreation;

/**
 *
 */
public interface MockTypeValidator<T> {
    void validate();
}
