package org.powermock.api.mockito.internal.mockcreation;

public class RuntimeExceptionProxy extends RuntimeException {
    public RuntimeExceptionProxy(Throwable t) {
        super(t);
    }
}

