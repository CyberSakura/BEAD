package org.powermock.reflect.internal.proxy;

public interface AnotherInterface {
}
