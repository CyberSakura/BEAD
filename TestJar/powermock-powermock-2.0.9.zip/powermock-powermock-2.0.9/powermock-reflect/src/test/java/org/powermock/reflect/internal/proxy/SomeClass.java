package org.powermock.reflect.internal.proxy;

/**
 *
 */
public class SomeClass {
}
